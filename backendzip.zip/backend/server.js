const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();

app.use(cors());
app.use(express.json());

app.use(express.static(path.join(__dirname, "public")));

const dataPath = path.join(__dirname, "data");

const farmersFile = path.join(dataPath, "farmers.json");
const adminsFile = path.join(dataPath, "admins.json");
const cropsFile = path.join(dataPath, "crops.json");
const centersFile = path.join(dataPath, "centers.json");
const requestsFile = path.join(dataPath, "requests.json");
const slotsFile = path.join(dataPath, "slots.json");
const paymentsFile = path.join(dataPath, "payments.json");
const notificationsFile = path.join(dataPath, "notifications.json");


function readJSON(file) {
    try {
        if (!fs.existsSync(file)) {
            fs.writeFileSync(file, "[]");
        }

        return JSON.parse(
            fs.readFileSync(file, "utf8")
        );

    } catch (error) {

        console.log("Error reading:", file);

        return [];
    }
}


function writeJSON(file, data) {

    fs.writeFileSync(
        file,
        JSON.stringify(data, null, 2)
    );
}


/* =========================
   HOME
========================= */

app.get("/", function (req, res) {

    res.sendFile(
        path.join(__dirname, "public", "index.html")
    );

});


/* =========================
   HEALTH CHECK
========================= */

app.get("/api/health", function (req, res) {

    res.json({
        success: true,
        message: "Smart Procurement Server is running."
    });

});


/* =========================
   FARMER REGISTER
========================= */

app.post("/api/farmers/register", function (req, res) {

    const farmers = readJSON(farmersFile);

    const {
        name,
        phone,
        aadhaar,
        village,
        mandal,
        district,
        survey,
        landArea,
        ownership,
        irrigation,
        password
    } = req.body;


    if (!name || !phone || !password) {

        return res.json({
            success: false,
            message: "Name, phone and password are required."
        });

    }


    const existing = farmers.find(
        farmer => farmer.phone === phone
    );


    if (existing) {

        return res.json({
            success: false,
            message: "Phone number already registered."
        });

    }


    const farmerId =
        "FRM-" +
        new Date().getFullYear() +
        "-" +
        String(farmers.length + 1).padStart(4, "0");


    const farmer = {

        id: farmers.length + 1,

        farmerId,

        name,

        phone,

        aadhaar,

        village,

        mandal,

        district,

        survey,

        landArea,

        ownership,

        irrigation,

        password

    };


    farmers.push(farmer);

    writeJSON(
        farmersFile,
        farmers
    );


    res.json({

        success: true,

        message: "Farmer registered successfully.",

        data: farmer

    });

});


/* =========================
   FARMER LOGIN
========================= */

app.post("/api/farmers/login", function (req, res) {

    const farmers = readJSON(farmersFile);

    const {
        phone,
        password
    } = req.body;


    const farmer = farmers.find(

        f =>
            f.phone === phone &&
            f.password === password

    );


    if (!farmer) {

        return res.json({

            success: false,

            message: "Invalid phone number or password."

        });

    }


    res.json({

        success: true,

        message: "Login successful.",

        data: farmer

    });

});


/* =========================
   ADMIN LOGIN
========================= */

app.post("/api/admin/login", function (req, res) {

    const admins = readJSON(adminsFile);

    const {
        email,
        password
    } = req.body;


    const admin = admins.find(

        a =>
            a.email === email &&
            a.password === password

    );


    if (!admin) {

        return res.json({

            success: false,

            message: "Invalid admin credentials."

        });

    }


    res.json({

        success: true,

        message: "Admin login successful.",

        data: admin

    });

});


/* =========================
   GET CROPS
========================= */

app.get("/api/crops", function (req, res) {

    const crops = readJSON(cropsFile);

    res.json({

        success: true,

        crops

    });

});


/* =========================
   GET CENTERS
========================= */

app.get("/api/centers", function (req, res) {

    const centers = readJSON(centersFile);

    res.json({

        success: true,

        centers

    });

});


/* =========================
   SMART CENTRE RECOMMENDATION
========================= */

app.post("/api/recommend-center", function (req, res) {

    const centers = readJSON(centersFile);

    const requests = readJSON(requestsFile);

    const {
        crop,
        district
    } = req.body;


    const matchingCenters = centers

        .filter(center =>
            center.crops.includes(crop)
        )

        .map(center => {

            const queueLength =
                requests.filter(

                    request =>
                        request.center === center.name &&
                        request.status !== "Completed"

                ).length;


            let score = 50;


            if (
                center.district &&
                center.district.toLowerCase() ===
                district.toLowerCase()
            ) {

                score += 30;

            }


            score -= queueLength * 5;


            if (score < 0) {

                score = 0;

            }


            return {

                ...center,

                queueLength,

                recommendationScore: score

            };

        })


        .sort(

            (a, b) =>
                b.recommendationScore -
                a.recommendationScore

        );


    res.json({

        success: true,

        recommendations: matchingCenters

    });

});


/* =========================
   GET SLOTS
========================= */

app.get("/api/slots/:center", function (req, res) {

    const center =
        decodeURIComponent(
            req.params.center
        );


    const slots =
        readJSON(slotsFile);


    const availableSlots =
        slots.filter(

            slot =>

                slot.center === center &&
                slot.booked < slot.capacity

        );


    res.json({

        success: true,

        center,

        slots: availableSlots

    });

});


/* =========================
   CREATE PROCUREMENT REQUEST
========================= */

app.post("/api/requests", function (req, res) {

    const requests =
        readJSON(requestsFile);


    const slots =
        readJSON(slotsFile);


    const {
        farmerId,
        farmerName,
        crop,
        quantity,
        unit,
        district,
        center,
        slotId,
        sellingDate
    } = req.body;


    const slot =
        slots.find(

            s =>
                String(s.id) ===
                String(slotId)

        );


    if (!slot) {

        return res.json({

            success: false,

            message: "Selected slot not found."

        });

    }


    if (slot.booked >= slot.capacity) {

        return res.json({

            success: false,

            message: "Selected slot is full."

        });

    }


    slot.booked++;


    writeJSON(
        slotsFile,
        slots
    );


    const token =

        "PROC-" +

        new Date().getFullYear() +

        "-" +

        String(
            requests.length + 1
        ).padStart(4, "0");


    const request = {

        id: requests.length + 1,

        requestId:
            "REQ-" +
            String(
                requests.length + 1
            ).padStart(4, "0"),

        farmerId,

        farmerName,

        crop,

        quantity,

        unit,

        district,

        center,

        slotId,

        date: sellingDate,

        time: slot.time,

        token,

        status: "Booked",

        checkedIn: false,

        qualityStatus: "Pending",

        qualityRemarks: "",

        actualWeight: 0,

        paymentStatus: "Pending",

        createdAt:
            new Date().toISOString()

    };


    requests.push(request);


    writeJSON(
        requestsFile,
        requests
    );


    res.json({

        success: true,

        message:
            "Procurement slot booked successfully.",

        data: request

    });

});


/* =========================
   GET ALL REQUESTS
========================= */

app.get("/api/requests", function (req, res) {

    const requests =
        readJSON(requestsFile);


    res.json({

        success: true,

        requests

    });

});


/* =========================
   GET REQUEST BY ID
========================= */

app.get("/api/requests/:id", function (req, res) {

    const requests =
        readJSON(requestsFile);


    const request =
        requests.find(

            r =>
                String(r.id) ===
                String(req.params.id)

        );


    if (!request) {

        return res.json({

            success: false,

            message: "Request not found."

        });

    }


    res.json({

        success: true,

        data: request

    });

});


/* =========================
   QUEUE
========================= */

app.get("/api/queue/:center", function (req, res) {

    const requests =
        readJSON(requestsFile);


    const center =
        decodeURIComponent(
            req.params.center
        );


    const queue =
        requests.filter(

            request =>

                request.center === center &&
                request.status !== "Completed"

        );


    res.json({

        success: true,

        center,

        queue,

        currentToken:
            queue.length > 0
                ? queue[0].token
                : null,

        peopleWaiting:
            queue.length

    });

});


/* =========================
   QR CHECK-IN
========================= */

app.put("/api/requests/:id/checkin", function (req, res) {

    const requests =
        readJSON(requestsFile);


    const request =
        requests.find(

            r =>
                String(r.id) ===
                String(req.params.id)

        );


    if (!request) {

        return res.json({

            success: false,

            message: "Request not found."

        });

    }


    request.checkedIn = true;

    request.status = "Checked In";


    writeJSON(
        requestsFile,
        requests
    );


    res.json({

        success: true,

        message:
            "Farmer checked in successfully.",

        data: request

    });

});


/* =========================
   QUALITY VERIFICATION
========================= */

app.put("/api/requests/:id/quality", function (req, res) {

    const requests =
        readJSON(requestsFile);


    const request =
        requests.find(

            r =>
                String(r.id) ===
                String(req.params.id)

        );


    if (!request) {

        return res.json({

            success: false,

            message: "Request not found."

        });

    }


    const {
        qualityStatus,
        qualityRemarks
    } = req.body;


    request.qualityStatus =
        qualityStatus;


    request.qualityRemarks =
        qualityRemarks || "";


    if (
        qualityStatus ===
        "Verified"
    ) {

        request.status =
            "Quality Verified";

    } else {

        request.status =
            "Quality Rejected";

    }


    writeJSON(
        requestsFile,
        requests
    );


    res.json({

        success: true,

        message:
            "Quality verification updated.",

        data: request

    });

});


/* =========================
   WEIGHING
========================= */

app.put("/api/requests/:id/weigh", function (req, res) {

    const requests =
        readJSON(requestsFile);


    const request =
        requests.find(

            r =>
                String(r.id) ===
                String(req.params.id)

        );


    if (!request) {

        return res.json({

            success: false,

            message: "Request not found."

        });

    }


    const {
        actualWeight
    } = req.body;


    request.actualWeight =
        Number(actualWeight);


    request.status =
        "Weighed";


    writeJSON(
        requestsFile,
        requests
    );


    res.json({

        success: true,

        message:
            "Weight recorded successfully.",

        data: request

    });

});


/* =========================
   COMPLETE PROCUREMENT
========================= */

app.put("/api/requests/:id/complete", function (req, res) {

    const requests =
        readJSON(requestsFile);


    const request =
        requests.find(

            r =>
                String(r.id) ===
                String(req.params.id)

        );


    if (!request) {

        return res.json({

            success: false,

            message: "Request not found."

        });

    }


    request.status =
        "Completed";


    request.paymentStatus =
        "Pending";


    writeJSON(
        requestsFile,
        requests
    );


    res.json({

        success: true,

        message:
            "Procurement completed successfully.",

        data: request

    });

});


/* =========================
   PAYMENT
========================= */

app.post("/api/payments", function (req, res) {

    const payments =
        readJSON(paymentsFile);


    const requests =
        readJSON(requestsFile);


    const {
        requestId,
        amount,
        paymentMethod
    } = req.body;


    const request =
        requests.find(

            r =>
                String(r.id) ===
                String(requestId)

        );


    if (!request) {

        return res.json({

            success: false,

            message: "Request not found."

        });

    }


    const payment = {

        id:
            payments.length + 1,

        requestId,

        farmerId:
            request.farmerId,

        amount:
            Number(amount),

        paymentMethod,

        status: "Paid",

        transactionId:
            "TXN" +
            Date.now(),

        date:
            new Date().toISOString()

    };


    payments.push(payment);


    writeJSON(
        paymentsFile,
        payments
    );


    request.paymentStatus =
        "Paid";


    writeJSON(
        requestsFile,
        requests
    );


    res.json({

        success: true,

        message:
            "Payment processed successfully.",

        data: payment

    });

});


/* =========================
   PAYMENTS
========================= */

app.get("/api/payments", function (req, res) {

    const payments =
        readJSON(paymentsFile);


    res.json({

        success: true,

        payments

    });

});


/* =========================
   NOTIFICATIONS
========================= */

app.get("/api/notifications/:farmerId", function (req, res) {

    const notifications =
        readJSON(notificationsFile);


    const farmerNotifications =
        notifications.filter(

            notification =>

                String(
                    notification.farmerId
                ) ===
                String(req.params.farmerId)

        );


    res.json({

        success: true,

        notifications:
            farmerNotifications

    });

});


/* =========================
   START SERVER
========================= */

const PORT = 5000;


app.listen(
    PORT,
    function () {

        console.log(
            "Smart Procurement Server running at http://localhost:" +
            PORT
        );

    }
);