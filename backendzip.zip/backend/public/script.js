// ==========================================
// FARMER REGISTRATION
// ==========================================

const registrationForm =
    document.getElementById("registrationForm");


if (registrationForm) {

    registrationForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            const farmer = {

                name:
                    document.getElementById("name").value,

                phone:
                    document.getElementById("phone").value,

                aadhaar:
                    document.getElementById("aadhaar").value,

                village:
                    document.getElementById("village").value,

                mandal:
                    document.getElementById("mandal").value,

                district:
                    document.getElementById("district").value,

                survey:
                    document.getElementById("survey").value,

                landArea:
                    document.getElementById("landArea").value,

                ownership:
                    document.getElementById("ownership").value,

                irrigation:
                    document.getElementById("irrigation").value,

                password:
                    document.getElementById("password").value

            };


            const response =
                await fetch("/api/farmers/register", {

                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify(farmer)

                });


            const data =
                await response.json();


            if (data.success) {

                alert(
                    "Registration successful!\n\n" +
                    "Your Farmer ID is:\n" +
                    data.farmer.farmerId
                );


                localStorage.setItem(
                    "farmer",
                    JSON.stringify(data.farmer)
                );


                window.location.href =
                    "farmer-login.html";

            }

            else {

                alert(data.message);

            }

        }

    );

}


// ==========================================
// FARMER LOGIN
// ==========================================

const farmerLoginForm =
    document.getElementById("farmerLoginForm");


if (farmerLoginForm) {

    farmerLoginForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            const response =
                await fetch("/api/farmers/login", {

                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        phone:
                            document
                                .getElementById(
                                    "loginPhone"
                                ).value,

                        password:
                            document
                                .getElementById(
                                    "loginPassword"
                                ).value

                    })

                });


            const data =
                await response.json();


            if (data.success) {

                localStorage.setItem(
                    "farmer",
                    JSON.stringify(data.farmer)
                );


                window.location.href =
                    "farmer-dashboard.html";

            }

            else {

                alert(data.message);

            }

        }

    );

}


// ==========================================
// ADMIN LOGIN
// ==========================================

const adminLoginForm =
    document.getElementById("adminLoginForm");


if (adminLoginForm) {

    adminLoginForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            const response =
                await fetch("/api/admin/login", {

                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        email:
                            document
                                .getElementById(
                                    "adminEmail"
                                ).value,

                        password:
                            document
                                .getElementById(
                                    "adminPassword"
                                ).value

                    })

                });


            const data =
                await response.json();


            if (data.success) {

                localStorage.setItem(
                    "admin",
                    JSON.stringify(data.admin)
                );


                window.location.href =
                    "admin-dashboard.html";

            }

            else {

                alert(data.message);

            }

        }

    );

}


// ==========================================
// LOAD CROPS
// ==========================================

const requestCrop =
    document.getElementById("requestCrop");


if (requestCrop) {

    fetch("/api/crops")

        .then(response =>
            response.json()
        )

        .then(crops => {

            crops.forEach(crop => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    crop.name;

                option.textContent =
                    crop.name +
                    " - ₹" +
                    crop.price +
                    "/" +
                    crop.unit;

                requestCrop.appendChild(
                    option
                );

            });

        });

}


// ==========================================
// LOAD CENTERS
// ==========================================

const requestCenter =
    document.getElementById("requestCenter");


if (requestCenter) {

    fetch("/api/procurement-centers")

        .then(response =>
            response.json()
        )

        .then(centers => {

            centers.forEach(center => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    center.name;

                option.textContent =
                    center.name;

                requestCenter.appendChild(
                    option
                );

            });

        });

}


// ==========================================
// PROCUREMENT REQUEST
// ==========================================

const procurementForm =
    document.getElementById(
        "procurementForm"
    );


if (procurementForm) {

    procurementForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            const farmer =
                JSON.parse(
                    localStorage.getItem(
                        "farmer"
                    )
                );


            if (!farmer) {

                alert(
                    "Please login first."
                );

                window.location.href =
                    "farmer-login.html";

                return;

            }


            const request = {

                farmerId:
                    farmer.id,

                farmerName:
                    farmer.name,

                crop:
                    document.getElementById(
                        "requestCrop"
                    ).value,

                quantity:
                    document.getElementById(
                        "requestQuantity"
                    ).value,

                unit:
                    document.getElementById(
                        "requestUnit"
                    ).value,

                center:
                    document.getElementById(
                        "requestCenter"
                    ).value,

                sellingDate:
                    document.getElementById(
                        "requestDate"
                    ).value

            };


            const response =
                await fetch(
                    "/api/requests",
                    {

                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body:
                            JSON.stringify(
                                request
                            )

                    }
                );


            const data =
                await response.json();


            if (data.success) {

                alert(
                    "Procurement request submitted!\n\n" +
                    "Virtual Token:\n" +
                    data.request.tokenNumber
                );


                window.location.href =
                    "status.html";

            }

            else {

                alert(data.message);

            }

        }

    );

}


// ==========================================
// FARMER DASHBOARD
// ==========================================

if (
    window.location.pathname.includes(
        "farmer-dashboard"
    )
) {

    const farmer =
        JSON.parse(
            localStorage.getItem("farmer")
        );


    if (!farmer) {

        window.location.href =
            "farmer-login.html";

    }

    else {

        document.getElementById(
            "welcome"
        ).textContent =
            "Welcome, " +
            farmer.name +
            " 👨‍🌾";


        fetch(
            "/api/requests/farmer/" +
            farmer.id
        )

        .then(response =>
            response.json()
        )

        .then(requests => {

            if (requests.length > 0) {

                const latest =
                    requests[
                        requests.length - 1
                    ];


                document.getElementById(
                    "tokenInfo"
                ).textContent =
                    latest.tokenNumber;


                document.getElementById(
                    "queueInfo"
                ).textContent =
                    latest.status;


                document.getElementById(
                    "paymentInfo"
                ).textContent =
                    latest.paymentStatus;


                document.getElementById(
                    "tokenBox"
                ).innerHTML = `

                    <h2>
                        🎟️ ${latest.tokenNumber}
                    </h2>

                    <p>
                        <strong>Crop:</strong>
                        ${latest.crop}
                    </p>

                    <p>
                        <strong>Quantity:</strong>
                        ${latest.quantity}
                        ${latest.unit}
                    </p>

                    <p>
                        <strong>Center:</strong>
                        ${latest.center}
                    </p>

                    <p>
                        <strong>Status:</strong>
                        ${latest.status}
                    </p>

                `;

            }

        });

    }

}


// ==========================================
// STATUS PAGE
// ==========================================

if (
    window.location.pathname.includes(
        "status"
    )
) {

    const farmer =
        JSON.parse(
            localStorage.getItem("farmer")
        );


    if (!farmer) {

        window.location.href =
            "farmer-login.html";

    }

    else {

        fetch(
            "/api/requests/farmer/" +
            farmer.id
        )

        .then(response =>
            response.json()
        )

        .then(requests => {

            const container =
                document.getElementById(
                    "statusContainer"
                );


            if (requests.length === 0) {

                container.innerHTML = `

                    <div class="data-box">

                        No procurement requests yet.

                        <br><br>

                        <a href="procurement.html"
                           class="btn">

                            Submit Request

                        </a>

                    </div>

                `;

                return;

            }


            let output = "";


            requests.forEach(request => {

                output += `

                    <div class="status-card">

                        <h2>
                            🎟️
                            ${request.tokenNumber}
                        </h2>

                        <p>
                            <strong>Crop:</strong>
                            ${request.crop}
                        </p>

                        <p>
                            <strong>Quantity:</strong>
                            ${request.quantity}
                            ${request.unit}
                        </p>

                        <p>
                            <strong>Center:</strong>
                            ${request.center}
                        </p>

                        <p>
                            <strong>Status:</strong>
                            ${request.status}
                        </p>

                        <p>
                            <strong>Quality:</strong>
                            ${request.qualityStatus}
                        </p>

                        <p>
                            <strong>Weight:</strong>
                            ${request.weight || "Pending"}
                        </p>

                        <p>
                            <strong>Payment:</strong>
                            ${request.paymentStatus}
                        </p>


                        <div class="timeline">

                            <span>
                                ✓ Request
                            </span>

                            <span>
                                ✓ Queue
                            </span>

                            <span>
                                ${
                                    request.qualityStatus
                                    === "Verified"
                                    ? "✓"
                                    : "○"
                                }
                                Quality
                            </span>

                            <span>
                                ${
                                    request.weight
                                    ? "✓"
                                    : "○"
                                }
                                Weighing
                            </span>

                            <span>
                                ${
                                    request.status
                                    === "Completed"
                                    ? "✓"
                                    : "○"
                                }
                                Payment
                            </span>

                        </div>

                    </div>

                `;

            });


            container.innerHTML =
                output;

        });

    }

}


// ==========================================
// ADMIN DASHBOARD
// ==========================================

if (
    window.location.pathname.includes(
        "admin-dashboard"
    )
) {

    const admin =
        localStorage.getItem("admin");


    if (!admin) {

        window.location.href =
            "admin-login.html";

    }

    else {

        loadAdminDashboard();

    }

}


async function loadAdminDashboard() {

    const dashboardResponse =
        await fetch(
            "/api/dashboard"
        );


    const dashboard =
        await dashboardResponse.json();


    document.getElementById(
        "totalFarmers"
    ).textContent =
        dashboard.farmers;


    document.getElementById(
        "totalCrops"
    ).textContent =
        dashboard.crops;


    document.getElementById(
        "totalRequests"
    ).textContent =
        dashboard.requests;


    document.getElementById(
        "totalWaiting"
    ).textContent =
        dashboard.waiting;


    document.getElementById(
        "totalPayments"
    ).textContent =
        "₹" +
        dashboard.payments;


    // Requests

    const requestResponse =
        await fetch(
            "/api/requests"
        );


    const requests =
        await requestResponse.json();


    let requestOutput = "";


    requests.forEach(request => {

        requestOutput += `

            <div class="data-box">

                <strong>
                    ${request.tokenNumber}
                </strong>

                <br>

                Farmer:
                ${request.farmerName}

                <br>

                Crop:
                ${request.crop}

                <br>

                Quantity:
                ${request.quantity}
                ${request.unit}

                <br>

                Center:
                ${request.center}

                <br>

                Status:
                ${request.status}

                <br>

                Quality:
                ${request.qualityStatus}

                <br><br>


                <button
                    onclick="verifyQuality(${request.id})">

                    ✓ Verify Quality

                </button>


                <button
                    onclick="recordWeight(${request.id})">

                    ⚖️ Record Weight

                </button>


                <button
                    onclick="completeRequest(${request.id})">

                    ✓ Complete

                </button>

            </div>

        `;

    });


    document.getElementById(
        "adminRequests"
    ).innerHTML =
        requestOutput || "No requests";


    // Queue

    const waiting =
        requests.filter(
            r =>
                r.status ===
                "Waiting"
        );


    let queueOutput = "";


    waiting.forEach(
        (request, index) => {

            queueOutput += `

                <div class="data-box">

                    🎟️
                    <strong>
                        ${request.tokenNumber}
                    </strong>

                    <br>

                    Farmer:
                    ${request.farmerName}

                    <br>

                    Crop:
                    ${request.crop}

                    <br>

                    People Ahead:
                    ${index}

                    <br>

                    Estimated Wait:
                    ${index * 15} minutes

                </div>

            `;

        }
    );


    document.getElementById(
        "adminQueue"
    ).innerHTML =
        queueOutput ||
        "No farmers waiting";


    // Farmers

    const farmerResponse =
        await fetch(
            "/api/farmers"
        );


    const farmers =
        await farmerResponse.json();


    let farmerOutput = "";


    farmers.forEach(farmer => {

        farmerOutput += `

            <div class="data-box">

                <strong>
                    ${farmer.farmerId}
                </strong>

                <br>

                Name:
                ${farmer.name}

                <br>

                Phone:
                ${farmer.phone}

                <br>

                Village:
                ${farmer.village}

                <br>

                District:
                ${farmer.district}

            </div>

        `;

    });


    document.getElementById(
        "adminFarmers"
    ).innerHTML =
        farmerOutput ||
        "No farmers registered";

}


// ==========================================
// ADMIN ACTIONS
// ==========================================

async function verifyQuality(id) {

    await fetch(
        "/api/requests/" +
        id +
        "/quality",
        {

            method: "PUT",

            headers: {
                "Content-Type":
                    "application/json"
            },

            body: JSON.stringify({

                qualityStatus:
                    "Verified"

            })

        }
    );


    alert(
        "Quality verified successfully"
    );


    location.reload();

}


async function recordWeight(id) {

    const weight =
        prompt(
            "Enter actual weight:"
        );


    if (!weight) {

        return;

    }


    await fetch(
        "/api/requests/" +
        id +
        "/weigh",
        {

            method: "PUT",

            headers: {
                "Content-Type":
                    "application/json"
            },

            body:
                JSON.stringify({
                    weight: weight
                })

        }
    );


    alert(
        "Weight recorded successfully"
    );


    location.reload();

}


async function completeRequest(id) {

    await fetch(
        "/api/requests/" +
        id +
        "/status",
        {

            method: "PUT",

            headers: {
                "Content-Type":
                    "application/json"
            },

            body:
                JSON.stringify({
                    status:
                        "Completed"
                })

        }
    );


    alert(
        "Procurement completed"
    );


    location.reload();

}


// ==========================================
// LOGOUT
// ==========================================

function logout() {

    localStorage.removeItem(
        "farmer"
    );

    localStorage.removeItem(
        "admin"
    );

    window.location.href =
        "index.html";

}